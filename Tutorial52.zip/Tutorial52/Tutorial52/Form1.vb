﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click
        'assign value dalam memory
        Dim intCount As Integer = 0

        'set initial value for intcount
        Do While intCount < 10
            lstOutput.Items.Add("Do While")
            intCount = intCount + 1
        Loop

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clear
        lstOutput.Items.Clear()
    End Sub
End Class
