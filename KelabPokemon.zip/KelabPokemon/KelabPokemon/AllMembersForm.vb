﻿Public Class AllMembersForm
    Private Sub AllMembersForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'AllMembersKelabPokemonDataSet.Members' table. You can move, or remove it, as needed.
        Me.MembersTableAdapter.Fill(Me.AllMembersKelabPokemonDataSet.Members)

    End Sub

    Private Sub mnuFileCloseAllMembers_Click(sender As Object, e As EventArgs) Handles mnuFileCloseAllMembers.Click
        Me.Close()
    End Sub

    Private Sub mnuFileSaveAllMembers_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAllMembers.Click
        Me.MembersTableAdapter.Update(Me.AllMembersKelabPokemonDataSet.Members)
    End Sub
End Class