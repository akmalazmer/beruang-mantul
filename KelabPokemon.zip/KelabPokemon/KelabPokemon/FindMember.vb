﻿Public Class FindMember
    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub txtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtLastName.TextChanged

    End Sub

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        'search function
        Me.MembersTableAdapter.Fill(Me.FindMemberKelabPokemonDataSet.Members, txtLastName.Text)
    End Sub

    Private Sub FindMember_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class