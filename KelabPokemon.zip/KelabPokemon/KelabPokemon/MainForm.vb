﻿Public Class MainForm
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuMembershipListAll_Click(sender As Object, e As EventArgs) Handles mnuMembershipListAll.Click
        'Create an instance of ALLMembersForm
        Dim frmAllMembers As New AllMembersForm

        'display the form
        frmAllMembers.ShowDialog()
    End Sub

    Private Sub mnuMemberAddNew_Click(sender As Object, e As EventArgs) Handles mnuMemberAddNew.Click
        'create instances
        Dim frmAddMember As New AddMembersForm

        'display the form
        frmAddMember.ShowDialog()
    End Sub

    Private Sub FindMemberToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FindMemberToolStripMenuItem.Click
        Dim frmFindMember As New FindMember

        frmFindMember.ShowDialog()

    End Sub

    Private Sub AllMembersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AllMembersToolStripMenuItem.Click
        Dim frmPaymentsAll As New AllPaymentsForm

        frmPaymentsAll.ShowDialog()

    End Sub
End Class
